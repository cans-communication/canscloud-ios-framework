//
//  canscloud_ios_framework.h
//  canscloud-ios-framework
//
//  Created by Siraphop Chaisirikul on 22/9/2565 BE.
//

#import <Foundation/Foundation.h>

//! Project version number for canscloud_ios_framework.
FOUNDATION_EXPORT double canscloud_ios_frameworkVersionNumber;

//! Project version string for canscloud_ios_framework.
FOUNDATION_EXPORT const unsigned char canscloud_ios_frameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <canscloud_ios_framework/PublicHeader.h>


